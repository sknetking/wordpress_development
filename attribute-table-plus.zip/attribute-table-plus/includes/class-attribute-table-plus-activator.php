<?php

/**
 * Fired during plugin activation
 *
 * @link       https://sknetking9.blogspot.com
 * @since      1.0.0
 *
 * @package    Attribute_Table_Plus
 * @subpackage Attribute_Table_Plus/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Attribute_Table_Plus
 * @subpackage Attribute_Table_Plus/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Attribute_Table_Plus_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
