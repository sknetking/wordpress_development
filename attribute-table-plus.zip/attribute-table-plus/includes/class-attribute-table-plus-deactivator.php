<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://sknetking9.blogspot.com
 * @since      1.0.0
 *
 * @package    Attribute_Table_Plus
 * @subpackage Attribute_Table_Plus/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Attribute_Table_Plus
 * @subpackage Attribute_Table_Plus/includes
 * @author     Shyam <sknetkingseo@gmail.com>
 */
class Attribute_Table_Plus_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
