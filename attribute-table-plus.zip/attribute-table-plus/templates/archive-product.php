<?php
/**
 * Override WooCommerce archive-product.php template to display products in a table format.
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

 get_header('shop');

 woocommerce_breadcrumb();
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.16.22/dist/css/uikit.min.css" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/uikit@3.16.22/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.16.22/dist/js/uikit-icons.min.js"></script>
<div class="container-fluid">
<div class="container py-5">
    <div class="row">
        <div class="col">
            <table class="table table-bordered table-hover">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col"><?php esc_html_e('Product', 'attribute-table-plus'); ?></th>
                        <th scope="col"><?php esc_html_e('Description', 'attribute-table-plus'); ?></th>
                        <th scope="col"><?php esc_html_e('Price', 'attribute-table-plus'); ?></th>
                        
                        <?php
                        $product_attributes = array();
                        while (have_posts()) :
                            the_post();
                            global $product;
                            $attributes = $product->get_attributes();
                            $product_attributes = array_merge($product_attributes, array_keys($attributes));
                        endwhile;

                        $product_attributes = array_unique($product_attributes);

                        foreach ($product_attributes as $attribute) {
                            echo '<th scope="col">' . ucfirst($attribute) . '</th>';
                        }
                        ?>
                        <th scope="col"><?php esc_html_e('Image', 'attribute-table-plus'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while (have_posts()) :
                        the_post();
                        global $product;
                        ?>
                        <tr>
                            <td>
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </td>
                            <td><?php echo wp_trim_words(get_the_excerpt(), 10); ?></td>
                            <td>
                                <?php echo $product->get_price_html(); ?>
                            </td>
                            <?php
                            foreach ($product_attributes as $attribute) {
                                echo '<td>';
                                $attribute_value = $product->get_attribute($attribute);
                                echo $attribute_value ? $attribute_value : '-';
                                echo '</td>';
                            }
                            ?>

                            <td>
                                <div uk-lightbox>
                                    <?php
                                    if (has_post_thumbnail()) {
                                        $thumbnail_url = get_the_post_thumbnail_url();
                                        echo "<a href='" . $thumbnail_url . "'>";
                                        the_post_thumbnail('thumbnail');
                                        echo "</a>";
                                    } else {
                                        echo esc_html__('---', 'attribute-table-plus');
                                    }

                                    if ($product->get_gallery_image_ids()) {
                                        $gallery_image_ids = $product->get_gallery_image_ids();
                                        $image_count = count($gallery_image_ids);

                                        if ($image_count > 1) {
                                            echo '<div class="product-gallery-slider" style="display:none">';
                                            foreach ($gallery_image_ids as $image_id) {
                                                echo '<a href="' . wp_get_attachment_url($image_id) . '">';
                                                echo wp_get_attachment_image($image_id, 'medium');
                                                echo '</a>';
                                            }
                                            echo '</div>';
                                        }
                                    }
                                    ?>
                                </div>
                            </td>
                        </tr>
                    <?php
                    endwhile;
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>

<?php
get_footer('shop');