<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://sknetking9.blogspot.com
 * @since             1.0.0
 * @package           Attribute_Table_Plus
 *
 * @wordpress-plugin
 * Plugin Name:       AttributeTablePlus
 * Plugin URI:        https://sknetking9.blogspot.com
 * Description:       AttributeTablePlus WooCommerce plugin that would display category products in a table, with table headers dynamically generated from every product. Display Simple product attributes in the table.
 * Version:           1.0.0
 * Author:            Shyam
 * Author URI:        https://sknetking9.blogspot.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       attribute-table-plus
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'ATTRIBUTE_TABLE_PLUS_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-attribute-table-plus-activator.php
 */
function activate_attribute_table_plus() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-attribute-table-plus-activator.php';
	Attribute_Table_Plus_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-attribute-table-plus-deactivator.php
 */
function deactivate_attribute_table_plus() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-attribute-table-plus-deactivator.php';
	Attribute_Table_Plus_Deactivator::deactivate();
}
register_activation_hook( __FILE__, 'activate_attribute_table_plus' );
register_deactivation_hook( __FILE__, 'deactivate_attribute_table_plus' );

//check woo-commerce plugin active or not 
function check_woocommerce_plugin() {
    // Check if WooCommerce is active
    if (!is_plugin_active('woocommerce/woocommerce.php')) {
        // WooCommerce is not active, display a message
        add_action('admin_notices', 'woocommerce_activation_notice');
    }
}
add_action('admin_init', 'check_woocommerce_plugin');

function woocommerce_activation_notice() {
    echo '<div class="notice notice-error"><p>Please activate the WooCommerce plugin to use this addon.</p></div>';
}


/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-attribute-table-plus.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_attribute_table_plus() {

	$plugin = new Attribute_Table_Plus();
	$plugin->run();

}
run_attribute_table_plus();

//To override WooCommerce templates using your plugin
function csp_locate_template( $template, $template_name, $template_path ) {
    $basename = basename( $template );
    if( $basename == 'archive-product.php' ) {
    $template = trailingslashit( plugin_dir_path( __FILE__ ) ) . '/templates/archive-product.php';
    }
    return $template;
   }
   add_filter( 'woocommerce_locate_template', 'csp_locate_template', 10, 3 );

// function your_plugin_custom_category_template($template) {
//     if (is_product_category()) {
//         $plugin_template = untrailingslashit(plugin_dir_path(__FILE__)) . '/templates/archive-product.php';
        
//         if (file_exists($plugin_template)) {
//             $template = $plugin_template;
//         }
//     }
    
//     return $template;
// }
// add_filter('template_include', 'your_plugin_custom_category_template');